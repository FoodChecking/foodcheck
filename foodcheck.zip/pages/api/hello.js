export default function handler(req, res) {
  res.status(200).json({ name: '푸드체크 서버 정상 작동' });
}
